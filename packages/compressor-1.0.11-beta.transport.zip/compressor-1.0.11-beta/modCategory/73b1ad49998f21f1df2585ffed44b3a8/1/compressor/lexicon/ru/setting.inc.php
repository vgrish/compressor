<?php

$_lang['area_compressor_main'] = 'Основные';

$_lang['setting_compressor_timing'] = 'Подсчет времени';
$_lang['setting_compressor_timing_desc'] = 'Подсчет времени обработки.';

$_lang['setting_compressor_compress_html_code'] = 'Сжимать html';
$_lang['setting_compressor_compress_html_code_desc'] = 'Сжимать html. Будут вырезаны комментарии и лишние пробелы.';

$_lang['setting_compressor_compress_combine_head_css_inline'] = 'Разместить css в "head" страницы';
$_lang['setting_compressor_compress_combine_head_css_inline_desc'] = 'Разместить сжатый css в "head" страницы.';

$_lang['setting_compressor_compress_combine_footer_css_inline'] = 'Разместить css в "footer" страницы';
$_lang['setting_compressor_compress_combine_footer_css_inline_desc'] = 'Разместить сжатый css в "footer" страницы.';

$_lang['setting_compressor_compress_combine_head_js_inline'] = 'Разместить js в "head" страницы';
$_lang['setting_compressor_compress_combine_head_js_inline_desc'] = 'Разместить сжатый js в "head" страницы.';

