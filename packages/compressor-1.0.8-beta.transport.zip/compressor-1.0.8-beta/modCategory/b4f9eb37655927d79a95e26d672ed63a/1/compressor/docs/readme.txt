--------------------
Compressor
--------------------
Author: Vgrish <vgrish@gmail.com>
--------------------