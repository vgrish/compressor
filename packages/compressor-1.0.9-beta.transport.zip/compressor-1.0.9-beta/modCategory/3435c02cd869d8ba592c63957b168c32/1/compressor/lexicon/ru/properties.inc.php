<?php

$_lang['compressor_prop_limit'] = 'Ограничение вывода Предметов на странице.';
